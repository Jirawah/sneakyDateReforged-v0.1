package com.sneakyDateReforged.ms_auth.exception;

public class SteamAccountBannedException extends RuntimeException {
    public SteamAccountBannedException(String message) {
        super(message);
    }
}
